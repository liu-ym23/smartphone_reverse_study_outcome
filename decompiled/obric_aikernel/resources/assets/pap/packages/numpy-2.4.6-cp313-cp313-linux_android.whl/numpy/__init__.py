"""
Minimal NumPy facade generated for workspace-specific wheel optimization.

This file intentionally keeps import-time work small and exposes most APIs
through lazy attribute loading. Test-only files may be stripped from the wheel.
"""

from __future__ import annotations

import importlib

from ._globals import _CopyMode, _NoValue
from .exceptions import (
    AxisError,
    ComplexWarning,
    ModuleDeprecationWarning,
    TooHardError,
    VisibleDeprecationWarning,
)
from .version import __version__
from . import _distributor_init  # noqa: F401
from . import core as _np_core


def _core_attr(name: str):
    return getattr(_np_core, name)


core = _np_core
array = _core_attr("array")
asarray = _core_attr("asarray")
bool = _core_attr("bool_")
dtype = _core_attr("dtype")
generic = _core_attr("generic")
ndarray = _core_attr("ndarray")
number = _core_attr("number")

_CORE_EXPORTS = ['abs', 'all', 'amax', 'amin', 'any', 'argmax', 'argmin', 'argsort', 'argwhere', 'array', 'asanyarray', 'asarray', 'ascontiguousarray', 'bool_', 'concatenate', 'count_nonzero', 'dtype', 'empty', 'expand_dims', 'float16', 'float32', 'float64', 'generic', 'inf', 'int16', 'int32', 'int64', 'int8', 'isdtype', 'isfinite', 'isinf', 'isnan', 'isscalar', 'issubdtype', 'max', 'maximum', 'mean', 'min', 'minimum', 'ndarray', 'newaxis', 'number', 'object_', 'ones', 'ones_like', 'reshape', 'sqrt', 'stack', 'sum', 'transpose', 'uint16', 'uint32', 'uint64', 'uint8', 'where', 'zeros', 'zeros_like']
_MODULE_ATTRS = {'angle': '.lib._function_base_impl', 'apply_along_axis': '.lib._shape_base_impl', 'apply_over_axes': '.lib._shape_base_impl', 'argmax': '.core.fromnumeric', 'argsort': '.core.fromnumeric', 'atleast_1d': '.core.shape_base', 'atleast_2d': '.core.shape_base', 'atleast_3d': '.core.shape_base', 'bitwise_and': '.core.umath', 'column_stack': '.lib._shape_base_impl', 'concatenate': '.core.multiarray', 'diagflat': '.lib._twodim_base_impl', 'diff': '.lib._function_base_impl', 'dot': '.core.multiarray', 'dstack': '.lib._shape_base_impl', 'exp': '.core.umath', 'expand_dims': '.lib._shape_base_impl', 'eye': '.lib._twodim_base_impl', 'flip': '.lib._function_base_impl', 'hsplit': '.lib._shape_base_impl', 'hstack': '.core.shape_base', 'index_exp': '.lib._index_tricks_impl', 'iscomplexobj': '.lib._type_check_impl', 'load': '.lib._npyio_impl', 'log10': '.core.umath', 'log2': '.core.umath', 'matrix': '.matrixlib.defmatrix', 'max': '.core.fromnumeric', 'mean': '.core.fromnumeric', 'median': '.lib._function_base_impl', 'multiply': '.core.umath', 'pad': '.lib._arraypad_impl', 'percentile': '.lib._function_base_impl', 'polyfit': '.lib._polynomial_impl', 'repeat': '.core.fromnumeric', 'rot90': '.lib._function_base_impl', 's_': '.lib._index_tricks_impl', 'sqrt': '.core.umath', 'stack': '.core.shape_base', 'sum': '.core.fromnumeric', 'transpose': '.core.fromnumeric', 'unicode': '.compat.py3k', 'unique': '.lib._arraysetops_impl', 'vander': '.lib._twodim_base_impl', 'vectorize': '.lib._function_base_impl', 'vstack': '.core.shape_base', 'where': '.core.multiarray', 'zeros_like': '.core.numeric'}
_SUBMODULES = {'fft': '.fft', 'linalg': '.linalg', 'ma': '.ma', 'random': '.random', 'typing': '.typing'}
_ALL_EXPORTS = ['__version__', 'abs', 'all', 'amax', 'amin', 'angle', 'any', 'apply_along_axis', 'apply_over_axes', 'argmax', 'argmin', 'argsort', 'argwhere', 'array', 'asanyarray', 'asarray', 'ascontiguousarray', 'atleast_1d', 'atleast_2d', 'atleast_3d', 'bitwise_and', 'bool_', 'column_stack', 'concatenate', 'count_nonzero', 'diagflat', 'diff', 'dot', 'dstack', 'dtype', 'empty', 'exp', 'expand_dims', 'eye', 'fft', 'flip', 'float16', 'float32', 'float64', 'generic', 'hsplit', 'hstack', 'index_exp', 'inf', 'int16', 'int32', 'int64', 'int8', 'iscomplexobj', 'isdtype', 'isfinite', 'isinf', 'isnan', 'isscalar', 'issubdtype', 'linalg', 'load', 'log10', 'log2', 'ma', 'matrix', 'max', 'maximum', 'mean', 'median', 'min', 'minimum', 'multiply', 'ndarray', 'newaxis', 'number', 'object_', 'ones', 'ones_like', 'pad', 'percentile', 'polyfit', 'random', 'repeat', 'reshape', 'rot90', 's_', 'show_config', 'sqrt', 'stack', 'sum', 'transpose', 'typing', 'uint16', 'uint32', 'uint64', 'uint8', 'unicode', 'unique', 'vander', 'vectorize', 'vstack', 'where', 'zeros', 'zeros_like']

__all__ = list(_ALL_EXPORTS)


def show_config():
    from numpy.__config__ import show as _show
    return _show()


def __getattr__(name: str):
    if name in _SUBMODULES:
        value = importlib.import_module(_SUBMODULES[name], __name__)
        globals()[name] = value
        return value
    if name in _MODULE_ATTRS:
        module = importlib.import_module(_MODULE_ATTRS[name], __name__)
        value = getattr(module, name)
        globals()[name] = value
        return value
    if name in _CORE_EXPORTS:
        value = _core_attr(name)
        globals()[name] = value
        return value
    if hasattr(_np_core, name):
        value = getattr(_np_core, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(globals()) | set(_ALL_EXPORTS) | set(dir(_np_core)))
