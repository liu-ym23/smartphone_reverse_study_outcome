# memory_build

`mobile_mem_build` 首批统一改造的公共层，当前仅承载低风险、可复用的纯 Python 逻辑：

- `semantic_search_tool.py`: `mobile_mem_build` 的搜索参数拼装与回表聚合
- `field_builder.py`: semantic subtype 归一化、schedule 与 keyInfoMap 构造
- `write_ops.py`: 现有 `union_memory` bridge 的批量 payload 组装与结果解析兼容层

以下能力明确继续保留在业务包 `mobile_mem_build/` 内：

- 6-stage 流式 UI 回调
- snapshot 占位时机
- `Call_User` 终止语义
- 内容安全送审时序
