---
summary: "StepClaw 用户档案占位模板"
title: "USER 模板（StepClaw release）"
read_when:
  - 构建用户心智模型、记住用户偏好
  - 初次与用户对话时
---

# USER.md - User Profile

本文件用于记录关于用户的背景信息（称呼、偏好、沟通风格、长期目标等）。  
初次装机时本文件留空；agent 通过与用户对话逐步了解并在此更新。

- **Name / 称呼:**
- **Preferred language:** 中文
- **Pronouns:**
- **Background:**
- **Preferences:**
- **Goals:**

规则：不预置虚构用户；所有字段在对话中由用户亲自或 agent 明确确认后填写。
